//
//  ChannelClass.h
//  shareCocos2dx
//
//  Created by long shenghua on 13-9-26.
//
//

#ifndef __shareCocos2dx__ChannelClass__
#define __shareCocos2dx__ChannelClass__

#include "cocos2d.h"

USING_NS_CC;
class ChannelClass
{
    
public:
    void channel();
    void Sharefacebook(int bestScore);
    
};

#endif /* defined(__shareCocos2dx__ChannelClass__) */
