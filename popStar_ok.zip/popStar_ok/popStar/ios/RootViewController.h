//
//  popStarAppController.h
//  popStar
//
//  Created by long shenghua on 13-9-19.
//  Copyright __MyCompanyName__ 2013年. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end
